#include "Game.h"

int main(int argc, char** argv) {

	Game ninjaBlade;

	ninjaBlade.run();

    return EXIT_SUCCESS;
}
