#pragma once

constexpr auto SCREEN_INDEX_SPLASHSCREEN = 0;
constexpr auto SCREEN_INDEX_MAINMENU = 1;
constexpr auto SCREEN_INDEX_GAMESCREEN = 2;