

namespace Shingine {
    extern int init();
	extern void quit();
}