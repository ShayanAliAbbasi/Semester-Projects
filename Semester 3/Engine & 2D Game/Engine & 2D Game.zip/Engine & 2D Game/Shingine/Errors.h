#pragma once
//This file holds some global error functions

#include <string>

namespace Shingine {

    extern void fatalError(std::string errorString);

}